using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent (typeof(GhostController))]
public class GhostFSM : fsm
{
    
}
